(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// ck-persona.js                                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Cols = new Mongo.Collection("cols");                                   // 1
                                                                       //
// Cols.insert({                                                       //
//   img_src: "ckal.png",                                              //
//   img_alt: "Red glasses; blue Adidas jacket.",                      //
//   desc: "This is how I will be remembered."                         //
// });                                                                 //
// Cols.insert({                                                       //
//   img_src: "ckal.png",                                              //
//   img_alt: "Red glasses; blue Adidas jacket.",                      //
//   desc: "This is how I will be remembered."                         //
// });                                                                 //
// Cols.insert({                                                       //
//   img_src: "ckal.png",                                              //
//   img_alt: "Red glasses; blue Adidas jacket.",                      //
//   desc: "This is how I will be remembered."                         //
// });                                                                 //
if (Meteor.isClient) {                                                 // 18
  Template.threeCols.helpers({                                         // 19
    title: "About Me",                                                 // 20
    desc: "Kalvin Chan. Number 8.",                                    // 21
    cols: [{                                                           // 22
      img_src: "ckal.png",                                             // 24
      img_alt: "Red glasses; blue Adidas jacket.",                     // 25
      img_desc: "This is how I will be remembered."                    // 26
    }, {                                                               //
      img_src: "ckal.png",                                             // 29
      img_alt: "Red glasses; blue Adidas jacket.",                     // 30
      img_desc: "This is how I will be remembered."                    // 31
    }, {                                                               //
      img_src: "ckal.png",                                             // 34
      img_alt: "Red glasses; blue Adidas jacket.",                     // 35
      img_desc: "This is how I will be remembered."                    // 36
    }]                                                                 //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=ck-persona.js.map
